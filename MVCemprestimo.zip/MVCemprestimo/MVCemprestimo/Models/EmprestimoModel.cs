﻿using System.ComponentModel.DataAnnotations;

namespace MVCemprestimo.Models
{
    public class EmprestimoModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        public string Name { get; set; }
        [Required(ErrorMessage = "O nome do fornecedor é obrigatório.")]
        public string fornecedor { get; set; }
        [Required(ErrorMessage = "O nome do livro é obrigatório.")]
        public string livroEmprestado { get; set; }
        public DateTime dataultimaAtualização { get; set; }= DateTime.Now;

    }
}
