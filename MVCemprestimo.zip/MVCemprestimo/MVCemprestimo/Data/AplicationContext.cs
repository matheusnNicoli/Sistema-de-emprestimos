﻿using Microsoft.EntityFrameworkCore;
using MVCemprestimo.Models;

namespace MVCemprestimo.Data
{
    public class AplicationContext : DbContext
    {
        public AplicationContext(DbContextOptions<AplicationContext> options) : base(options)
        {
        }
       
        public DbSet<EmprestimoModel>Emprestimos { get; set; }

    }
}
